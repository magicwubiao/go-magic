package bus

import (
	"sync"
	"sync/atomic"
	"time"
)

const defaultEventSubscriberBuffer = 16

// EventSubscription identifies a subscriber channel returned by EventBus.Subscribe
type EventSubscription struct {
	ID uint64
	C  <-chan Event
}

type eventSubscriber struct {
	ch chan Event
}

// EventKind represents the type of event
type EventKind int

const (
	EventKindLLMRequest EventKind = iota
	EventKindLLMResponse
	EventKindToolBefore
	EventKindToolAfter
	EventKindToolError
	EventKindTurnStart
	EventKindTurnEnd
	EventKindAgentStart
	EventKindAgentEnd
	EventKindError
	EventKindWarning
	EventKindSteering
	EventKindReflection
	EventKindPlanUpdate
	EventKindTrajectory
	EventKindMemoryUpdate
	EventKindTodoUpdate
	EventKindCount
)

func (k EventKind) String() string {
	switch k {
	case EventKindLLMRequest:
		return "llm_request"
	case EventKindLLMResponse:
		return "llm_response"
	case EventKindToolBefore:
		return "tool_before"
	case EventKindToolAfter:
		return "tool_after"
	case EventKindToolError:
		return "tool_error"
	case EventKindTurnStart:
		return "turn_start"
	case EventKindTurnEnd:
		return "turn_end"
	case EventKindAgentStart:
		return "agent_start"
	case EventKindAgentEnd:
		return "agent_end"
	case EventKindError:
		return "error"
	case EventKindWarning:
		return "warning"
	case EventKindSteering:
		return "steering"
	case EventKindReflection:
		return "reflection"
	case EventKindPlanUpdate:
		return "plan_update"
	case EventKindTrajectory:
		return "trajectory"
	case EventKindMemoryUpdate:
		return "memory_update"
	case EventKindTodoUpdate:
		return "todo_update"
	default:
		return "unknown"
	}
}

// Event represents an agent loop event
type Event struct {
	Kind      EventKind
	Time      time.Time
	Turn      int
	SessionID string
	Data      interface{}
}

// Int64 is an atomic int64 wrapper (compatible with Go 1.18)
type Int64 struct {
	v int64
}

// Add adds delta to the value
func (i *Int64) Add(delta int64) {
	atomic.AddInt64(&i.v, delta)
}

// Load returns the current value
func (i *Int64) Load() int64 {
	return atomic.LoadInt64(&i.v)
}

// EventBus is a lightweight multi-subscriber broadcaster for agent-loop events
type EventBus struct {
	mu      sync.RWMutex
	subs    map[uint64]eventSubscriber
	nextID  uint64
	closed  bool
	dropped [EventKindCount]Int64
}

// NewEventBus creates a new in-process event broadcaster
func NewEventBus() *EventBus {
	return &EventBus{
		subs: make(map[uint64]eventSubscriber),
	}
}

// Subscribe registers a new subscriber with the requested channel buffer size
// A non-positive buffer uses the default size
func (b *EventBus) Subscribe(buffer int) EventSubscription {
	if buffer <= 0 {
		buffer = defaultEventSubscriberBuffer
	}

	b.mu.Lock()
	defer b.mu.Unlock()

	if b.closed {
		ch := make(chan Event)
		close(ch)
		return EventSubscription{C: ch}
	}

	b.nextID++
	id := b.nextID
	ch := make(chan Event, buffer)
	b.subs[id] = eventSubscriber{ch: ch}
	return EventSubscription{ID: id, C: ch}
}

// Unsubscribe removes a subscriber and closes its channel
func (b *EventBus) Unsubscribe(id uint64) {
	b.mu.Lock()
	defer b.mu.Unlock()

	sub, ok := b.subs[id]
	if !ok {
		return
	}

	delete(b.subs, id)
	close(sub.ch)
}

// Emit broadcasts an event to all current subscribers without blocking
// When a subscriber channel is full, the event is dropped for that subscriber
func (b *EventBus) Emit(evt Event) {
	if evt.Time.IsZero() {
		evt.Time = time.Now()
	}

	b.mu.RLock()
	defer b.mu.RUnlock()

	if b.closed {
		return
	}

	for _, sub := range b.subs {
		select {
		case sub.ch <- evt:
		default:
			if evt.Kind < EventKindCount {
				b.dropped[evt.Kind].Add(1)
			}
		}
	}
}

// Dropped returns the number of dropped events for a given kind
func (b *EventBus) Dropped(kind EventKind) int64 {
	if kind >= EventKindCount {
		return 0
	}
	return b.dropped[kind].Load()
}

// Close closes all subscriber channels and stops future broadcasts
func (b *EventBus) Close() {
	b.mu.Lock()
	defer b.mu.Unlock()

	if b.closed {
		return
	}

	b.closed = true
	for id, sub := range b.subs {
		close(sub.ch)
		delete(b.subs, id)
	}
}

// EventLogger is a simple subscriber that logs events
type EventLogger struct {
	handlers map[EventKind]func(Event)
}

// NewEventLogger creates a new event logger
func NewEventLogger() *EventLogger {
	return &EventLogger{
		handlers: make(map[EventKind]func(Event)),
	}
}

// On registers a handler for a specific event kind
func (l *EventLogger) On(kind EventKind, handler func(Event)) {
	l.handlers[kind] = handler
}

// Handle processes an event
func (l *EventLogger) Handle(evt Event) {
	if handler, ok := l.handlers[evt.Kind]; ok && handler != nil {
		handler(evt)
	}
}
