package cortex

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/magicwubiao/go-magic/internal/provider"
)

// errInsufficientTrajectories is returned by evolve() when the trajectory
// store does not yet have enough data to run an evolution iteration. This is
// a normal condition for a freshly started system, so the evolution loop
// treats it as a skip rather than a real error to avoid log spam.
var errInsufficientTrajectories = errors.New("insufficient trajectories for evolution")

// ============================================================================
// GEPA Engine - Generative Evolutionary Prompt Alignment
// ============================================================================
// GEPA is the core self-evolution engine inspired by Hermes Agent.
// It learns from execution trajectories and evolves system prompts through
// an evolutionary optimization process.
//
// Algorithm:
// 1. Collect trajectories (task executions)
// 2. Evaluate effectiveness (success rate, efficiency)
// 3. Generate optimization strategies
// 4. Apply strategies to prompts
// 5. Iterate and converge (100-500 iterations)
// ============================================================================

// GEPAEngine is the main GEPA orchestrator
type GEPAEngine struct {
	mu sync.RWMutex

	// Configuration
	baseDir              string
	provider             provider.Provider
	convergenceThreshold float64 // Stop when improvement < threshold
	maxIterations        int
	populationSize       int

	// Components
	evaluator       *EffectivenessEvaluator
	generator       *StrategyGenerator
	optimizer       *PromptOptimizer
	trajectoryStore *TrajectoryStore

	// Evolution state
	generations  []Generation
	currentGen   int
	bestStrategy *OptimizationStrategy
	isConverged  bool

	// Lifecycle
	cancel context.CancelFunc // Stops the evolution goroutine

	// Metrics
	totalTrajectories int
	successRate       float64
	avgEffectiveness  float64
}

// Generation represents one evolution iteration
type Generation struct {
	ID           int                    `json:"id"`
	Timestamp    time.Time              `json:"timestamp"`
	Strategies   []OptimizationStrategy `json:"strategies"`
	BestStrategy *OptimizationStrategy  `json:"best_strategy"`
	AvgFitness   float64                `json:"avg_fitness"`
	Improvement  float64                `json:"improvement"`
	Trajectories []string               `json:"trajectory_ids"`
}

// OptimizationStrategy represents a prompt optimization strategy
type OptimizationStrategy struct {
	ID          string          `json:"id"`
	Name        string          `json:"name"`
	Description string          `json:"description"`
	Target      string          `json:"target"` // "soul", "system", "skills"
	Changes     []PromptChange  `json:"changes"`
	Fitness     float64         `json:"fitness"`
	Applied     bool            `json:"applied"`
	AppliedAt   *time.Time      `json:"applied_at,omitempty"`
	Results     *StrategyResult `json:"results,omitempty"`
}

// PromptChange represents a single prompt modification
type PromptChange struct {
	Type       string `json:"type"`    // "add", "remove", "modify", "reorder"
	Section    string `json:"section"` // Section name
	OldContent string `json:"old_content"`
	NewContent string `json:"new_content"`
	Reason     string `json:"reason"`
}

// StrategyResult tracks the outcome of applying a strategy
type StrategyResult struct {
	BeforeSuccessRate float64   `json:"before_success_rate"`
	AfterSuccessRate  float64   `json:"after_success_rate"`
	Improvement       float64   `json:"improvement"`
	SampleSize        int       `json:"sample_size"`
	MeasuredAt        time.Time `json:"measured_at"`
}

// EffectivenessScore represents a trajectory's effectiveness
type EffectivenessScore struct {
	TrajectoryID string  `json:"trajectory_id"`
	Success      bool    `json:"success"`
	Efficiency   float64 `json:"efficiency"`    // 0-1, based on turns vs optimal
	Quality      float64 `json:"quality"`       // 0-1, based on output quality
	ToolAccuracy float64 `json:"tool_accuracy"` // 0-1, correct tool usage
	OverallScore float64 `json:"overall_score"` // Weighted combination
}

// NewGEPAEngine creates a new GEPA engine
func NewGEPAEngine(baseDir string, prov provider.Provider, trajectoryStore *TrajectoryStore) *GEPAEngine {
	return &GEPAEngine{
		baseDir:              baseDir,
		provider:             prov,
		convergenceThreshold: 0.01, // 1% improvement threshold
		maxIterations:        500,
		populationSize:       10,
		evaluator:            NewEffectivenessEvaluator(),
		generator:            NewStrategyGenerator(prov),
		optimizer:            NewPromptOptimizer(prov),
		trajectoryStore:      trajectoryStore,
		generations:          make([]Generation, 0),
	}
}

// Start starts the GEPA evolution process
func (g *GEPAEngine) Start(ctx context.Context) error {
	g.mu.Lock()
	defer g.mu.Unlock()

	// Load previous generations
	g.loadGenerations()

	// Create a cancellable context so the evolution goroutine can be stopped
	if ctx == nil {
		ctx = context.Background()
	}
	ctx, g.cancel = context.WithCancel(ctx)

	// Start evolution loop in background
	go g.evolutionLoop(ctx)

	return nil
}

// Stop stops the GEPA evolution goroutine
func (g *GEPAEngine) Stop() {
	g.mu.Lock()
	if g.cancel != nil {
		g.cancel()
		g.cancel = nil
	}
	g.mu.Unlock()
}

// evolutionLoop runs the main GEPA evolution algorithm
func (g *GEPAEngine) evolutionLoop(ctx context.Context) {
	ticker := time.NewTicker(5 * time.Minute) // Evaluate every 5 minutes
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			// Check convergence under lock to avoid data race
			g.mu.RLock()
			converged := g.isConverged
			g.mu.RUnlock()
			if converged {
				continue
			}

			if err := g.evolve(ctx); err != nil {
				// Insufficient trajectories is a normal condition for a fresh
				// system — skip silently instead of spamming the log every
				// tick. Only log genuine evolution errors.
				if !errors.Is(err, errInsufficientTrajectories) {
					log.Printf("[GEPA] evolution error: %v", err)
				}
				continue
			}
		}
	}
}

// evolve performs one evolution iteration
func (g *GEPAEngine) evolve(ctx context.Context) error {
	// 阶段 (a)：持锁读取当前代数据并拷贝到局部变量，然后立即解锁，
	// 避免在阶段 (b) 的 LLM 网络调用期间长时间持锁阻塞其它读操作。
	g.mu.Lock()
	currentGen := g.currentGen
	populationSize := g.populationSize
	convergenceThreshold := g.convergenceThreshold
	prevGenerationsCount := len(g.generations)
	var prevBestFitness float64
	prevBestExists := false
	if prevGenerationsCount > 0 {
		prevBest := g.generations[prevGenerationsCount-1].BestStrategy
		if prevBest != nil {
			prevBestFitness = prevBest.Fitness
			prevBestExists = true
		}
	}
	g.mu.Unlock()

	// 阶段 (b)：不持锁执行耗时操作（含 LLM 网络调用）。
	// trajectoryStore 内部已有自己的锁，无需 g.mu 保护。
	// 1. Collect recent trajectories
	trajectories := g.trajectoryStore.GetTrajectories(100)
	if len(trajectories) < 3 {
		return errInsufficientTrajectories
	}

	// 2. Evaluate effectiveness
	scores := g.evaluator.EvaluateBatch(trajectories)

	// 3. Generate optimization strategies（LLM 调用，不持锁）
	strategies, err := g.generator.GenerateStrategies(ctx, scores, populationSize)
	if err != nil {
		return err
	}

	// 4. Evaluate strategies
	for i := range strategies {
		strategies[i].Fitness = g.evaluateStrategyFitness(&strategies[i], scores)
	}

	// 5. Select best strategy
	best := g.selectBestStrategy(strategies)
	if best == nil {
		return nil
	}

	// 6. Calculate improvement（基于阶段 (a) 读取的上一代最优 fitness）
	improvement := 0.0
	if prevBestExists {
		improvement = best.Fitness - prevBestFitness
	}

	// 阶段 (c)：重新持锁写回结果
	g.mu.Lock()
	defer g.mu.Unlock()

	// 7. Create new generation
	gen := Generation{
		ID:           currentGen + 1,
		Timestamp:    time.Now(),
		Strategies:   strategies,
		BestStrategy: best,
		AvgFitness:   g.calculateAvgFitness(strategies),
		Improvement:  improvement,
	}

	// 8. Check convergence
	if improvement < convergenceThreshold && len(g.generations) > 50 {
		g.isConverged = true
	}

	// 9. Save generation
	g.generations = append(g.generations, gen)
	g.currentGen = gen.ID
	g.bestStrategy = best
	g.saveGeneration(&gen)

	// 10. Update metrics
	g.updateMetrics(scores)

	return nil
}

// ApplyBestStrategy applies the best strategy to the system.
// Skips re-application if the strategy was already applied (idempotent).
func (g *GEPAEngine) ApplyBestStrategy(soul *SoulManager, systemPrompt string) (string, error) {
	g.mu.RLock()
	bestPtr := g.bestStrategy
	g.mu.RUnlock()

	if bestPtr == nil {
		return systemPrompt, nil
	}

	if bestPtr.Applied {
		return systemPrompt, nil
	}

	bestCopy := *bestPtr

	optimized, err := g.optimizer.Optimize(systemPrompt, bestCopy.Changes)
	if err != nil {
		return systemPrompt, err
	}

	now := time.Now()
	bestCopy.Applied = true
	bestCopy.AppliedAt = &now

	g.mu.Lock()
	g.bestStrategy = &bestCopy
	g.mu.Unlock()

	return optimized, nil
}

// evaluateStrategyFitness evaluates a strategy's potential fitness
func (g *GEPAEngine) evaluateStrategyFitness(strategy *OptimizationStrategy, scores []EffectivenessScore) float64 {
	// 基础分：平均效果分
	avgScore := 0.0
	if len(scores) > 0 {
		for _, s := range scores {
			avgScore += s.OverallScore
		}
		avgScore /= float64(len(scores))
	}

	// 基于策略 changes 的实际内容计算差异化 fitness，使不同策略 fitness 不同，
	// 让 selection 真正有意义（避免所有策略 fitness 仅由 avgScore 决定的"假进化"）。
	changesScore := 0.0
	totalContentLen := 0
	actionKeywordHits := 0
	// 中英文动作/优化关键词词表
	actionKeywords := []string{
		"add", "modify", "improve", "optimize", "enhance", "refine",
		"remove", "reorder", "fix", "clarify",
		"增加", "修改", "改进", "优化", "增强", "完善",
		"删除", "调整", "修复", "明确", "简化", "重排",
	}
	for _, c := range strategy.Changes {
		// 把可评估文本拼到一起做关键词密度统计
		text := strings.ToLower(c.NewContent + " " + c.Reason + " " + c.Section)
		totalContentLen += len(c.NewContent)
		for _, kw := range actionKeywords {
			if strings.Contains(text, kw) {
				actionKeywordHits++
			}
		}
	}

	// changes 数量贡献：1~5 个较为合理
	changeCount := len(strategy.Changes)
	switch {
	case changeCount == 0:
		// 没有 changes 的策略无意义，大幅降权
		changesScore = 0.1
	case changeCount <= 5:
		changesScore = 0.1 + 0.03*float64(changeCount)
	default:
		// 过多 changes 视为过度复杂，递减
		changesScore = 0.25 - 0.02*float64(changeCount-5)
		if changesScore < 0.05 {
			changesScore = 0.05
		}
	}

	// 内容实质度：基于 NewContent 字符长度（对数压缩，避免长文本主导）
	if totalContentLen > 0 {
		changesScore += math.Min(0.2, math.Log2(float64(totalContentLen+1))/50.0)
	}

	// 关键词密度贡献
	if changeCount > 0 {
		density := float64(actionKeywordHits) / float64(changeCount)
		changesScore += math.Min(0.15, density*0.05)
	}

	// 按目标类型加权
	multiplier := 1.0
	switch strategy.Target {
	case "soul":
		multiplier = 1.2 // 人格调整影响较大
	case "system":
		multiplier = 1.1
	case "skills":
		multiplier = 1.0
	}

	fitness := (avgScore + changesScore) * multiplier
	if fitness < 0 {
		fitness = 0
	}
	return fitness
}

// selectBestStrategy selects the best strategy from a population
func (g *GEPAEngine) selectBestStrategy(strategies []OptimizationStrategy) *OptimizationStrategy {
	if len(strategies) == 0 {
		return nil
	}

	// Sort by fitness
	sort.Slice(strategies, func(i, j int) bool {
		return strategies[i].Fitness > strategies[j].Fitness
	})

	best := strategies[0]
	return &best
}

// calculateAvgFitness calculates average fitness of strategies
func (g *GEPAEngine) calculateAvgFitness(strategies []OptimizationStrategy) float64 {
	if len(strategies) == 0 {
		return 0
	}

	total := 0.0
	for _, s := range strategies {
		total += s.Fitness
	}
	return total / float64(len(strategies))
}

// updateMetrics updates engine metrics
func (g *GEPAEngine) updateMetrics(scores []EffectivenessScore) {
	g.totalTrajectories = len(scores)

	successes := 0
	totalEffectiveness := 0.0
	for _, s := range scores {
		if s.Success {
			successes++
		}
		totalEffectiveness += s.OverallScore
	}

	if len(scores) > 0 {
		g.successRate = float64(successes) / float64(len(scores))
		g.avgEffectiveness = totalEffectiveness / float64(len(scores))
	}
}

// GetStats returns GEPA engine statistics
func (g *GEPAEngine) GetStats() map[string]interface{} {
	g.mu.RLock()
	defer g.mu.RUnlock()

	return map[string]interface{}{
		"current_generation":    g.currentGen,
		"is_converged":          g.isConverged,
		"total_trajectories":    g.totalTrajectories,
		"success_rate":          g.successRate,
		"avg_effectiveness":     g.avgEffectiveness,
		"best_strategy_id":      g.bestStrategy,
		"convergence_threshold": g.convergenceThreshold,
	}
}

// GetGenerations returns all generations
func (g *GEPAEngine) GetGenerations() []Generation {
	g.mu.RLock()
	defer g.mu.RUnlock()
	return g.generations
}

// saveGeneration saves a generation to disk
func (g *GEPAEngine) saveGeneration(gen *Generation) {
	path := filepath.Join(g.baseDir, "gepa", "generations", fmt.Sprintf("gen_%d.json", gen.ID))
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		log.Printf("[GEPA] failed to create generation dir: %v", err)
		return
	}

	data, err := json.MarshalIndent(gen, "", "  ")
	if err != nil {
		log.Printf("[GEPA] failed to marshal generation %d: %v", gen.ID, err)
		return
	}
	if err := os.WriteFile(path, data, 0644); err != nil {
		log.Printf("[GEPA] failed to write generation %d: %v", gen.ID, err)
	}
}

// loadGenerations loads previous generations from disk (capped at maxLoadedGenerations)
func (g *GEPAEngine) loadGenerations() {
	const maxLoadedGenerations = 200

	genDir := filepath.Join(g.baseDir, "gepa", "generations")
	entries, err := os.ReadDir(genDir)
	if err != nil {
		return
	}

	for _, entry := range entries {
		if entry.IsDir() || !strings.HasPrefix(entry.Name(), "gen_") {
			continue
		}

		path := filepath.Join(genDir, entry.Name())
		data, err := os.ReadFile(path)
		if err != nil {
			continue
		}

		var gen Generation
		if err := json.Unmarshal(data, &gen); err != nil {
			continue
		}

		g.generations = append(g.generations, gen)
		if gen.ID > g.currentGen {
			g.currentGen = gen.ID
			g.bestStrategy = gen.BestStrategy
		}
	}

	sort.Slice(g.generations, func(i, j int) bool {
		return g.generations[i].ID < g.generations[j].ID
	})

	if len(g.generations) > maxLoadedGenerations {
		g.generations = g.generations[len(g.generations)-maxLoadedGenerations:]
	}
}

// Reset resets the GEPA engine
func (g *GEPAEngine) Reset() error {
	g.Stop() // Stop the evolution goroutine first

	g.mu.Lock()
	defer g.mu.Unlock()

	g.generations = make([]Generation, 0)
	g.currentGen = 0
	g.bestStrategy = nil
	g.isConverged = false
	g.totalTrajectories = 0
	g.successRate = 0
	g.avgEffectiveness = 0

	// Clear saved generations
	genDir := filepath.Join(g.baseDir, "gepa", "generations")
	os.RemoveAll(genDir)

	return nil
}
